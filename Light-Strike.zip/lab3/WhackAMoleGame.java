import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class WhackAMoleGame extends JFrame {
    private JPanel gridPanel;
    private JButton[] gridButtons;
    private JLabel timerLabel, scoreLabel;
    private Timer moleTimer, gameTimer;
    private int score = 0;
    private int moleIndex = -1;
    private int timeRemaining = 30; // 30 seconds game duration

    public WhackAMoleGame() {
        // Set up the JFrame
        setTitle("Whack-a-Mole Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setSize(400, 500);

        // Top Panel (Start Button + Timer)
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());

        JButton startButton = new JButton("Start Game");
        timerLabel = new JLabel("Time: " + timeRemaining + "s");
        scoreLabel = new JLabel("Score: " + score);

        topPanel.add(startButton);
        topPanel.add(timerLabel);
        topPanel.add(scoreLabel);
        add(topPanel, BorderLayout.NORTH);

        // Grid Panel (3x3 Grid)
        gridPanel = new JPanel();
        gridPanel.setLayout(new GridLayout(3, 3));
        gridButtons = new JButton[9];

        for (int i = 0; i < 9; i++) {
            JButton button = new JButton();
            button.setBackground(Color.LIGHT_GRAY);
            button.addActionListener(new WhackListener(i));
            gridButtons[i] = button;
            gridPanel.add(button);
        }

        add(gridPanel, BorderLayout.CENTER);

        // Start Button Action Listener
        startButton.addActionListener(e -> startGame());

        // Keyboard Listener (Optional)
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key >= KeyEvent.VK_1 && key <= KeyEvent.VK_9) {
                    int index = key - KeyEvent.VK_1;
                    if (index == moleIndex) {
                        whackMole(index);
                    }
                }
            }
        });
        setFocusable(true);
    }

    private void startGame() {
        score = 0;
        timeRemaining = 30;
        timerLabel.setText("Time: " + timeRemaining + "s");
        scoreLabel.setText("Score: " + score);

        // Mole Timer: Changes mole position every second
        moleTimer = new Timer(1000, e -> spawnMole());
        moleTimer.start();

        // Game Timer: Ends the game after 30 seconds
        gameTimer = new Timer(1000, e -> {
            timeRemaining--;
            timerLabel.setText("Time: " + timeRemaining + "s");
            if (timeRemaining <= 0) {
                endGame();
            }
        });
        gameTimer.start();
    }

    private void spawnMole() {
        if (moleIndex != -1) {
            gridButtons[moleIndex].setBackground(Color.LIGHT_GRAY);
        }
        Random rand = new Random();
        moleIndex = rand.nextInt(9);
        gridButtons[moleIndex].setBackground(Color.GREEN);
    }

    private void whackMole(int index) {
        if (index == moleIndex) {
            score++;
            scoreLabel.setText("Score: " + score);
            gridButtons[index].setBackground(Color.LIGHT_GRAY);
            moleIndex = -1;
        }
    }

    private void endGame() {
        moleTimer.stop();
        gameTimer.stop();
        JOptionPane.showMessageDialog(this, "Game Over! You scored: " + score + " points.");
        for (JButton button : gridButtons) {
            button.setBackground(Color.LIGHT_GRAY);
        }
    }

    private class WhackListener implements ActionListener {
        private int index;

        public WhackListener(int index) {
            this.index = index;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            whackMole(index);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WhackAMoleGame game = new WhackAMoleGame();
            game.setVisible(true);
        });
    }
}
